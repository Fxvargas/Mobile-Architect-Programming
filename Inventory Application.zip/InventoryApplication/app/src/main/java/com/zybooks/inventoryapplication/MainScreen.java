package com.zybooks.inventoryapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainScreen extends AppCompatActivity {

    GridView gView;
    EditText itemName;
    EditText itemQty;
    Button addBtn;
    Button updateBtn;
    Button deleteBtn;
    Button viewBtn;
    DBInventory DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        gView = (GridView) findViewById(R.id.gridView1);
        itemName = (EditText) findViewById(R.id.editTextItemName);
        itemQty = (EditText) findViewById(R.id.editTextItemQty);
        addBtn = (Button) findViewById(R.id.addBtn);
        updateBtn = (Button) findViewById(R.id.updateBtn);
        deleteBtn = (Button) findViewById(R.id.delBtn);
        viewBtn = (Button) findViewById(R.id.viewBtn);

        DB = new DBInventory(this);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nameTXT = itemName.getText().toString();
                String qtyTXT = itemQty.getText().toString();

                if (nameTXT.equals("") || qtyTXT.equals("")) {

                    Toast.makeText(MainScreen.this, "Fill out blank fields", Toast.LENGTH_SHORT).show();

                } else {

                    Boolean checkAddData = DB.addData(nameTXT, qtyTXT);

                    if (checkAddData == true) {

                        Toast.makeText(MainScreen.this, "Item added", Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(MainScreen.this, "Item add failed", Toast.LENGTH_SHORT).show();

                    }

                }
            }
        });

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nameTXT = itemName.getText().toString();
                String qtyTXT = itemQty.getText().toString();

                if (nameTXT.equals("") || qtyTXT.equals("")) {

                    Toast.makeText(MainScreen.this, "Fill out blank fields", Toast.LENGTH_SHORT).show();

                } else {

                    Boolean checkUpdateData = DB.updateData(nameTXT, qtyTXT);

                    if (checkUpdateData == true) {

                        Toast.makeText(MainScreen.this, "Item updated", Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(MainScreen.this, "Item update failed", Toast.LENGTH_SHORT).show();

                    }

                }
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nameTXT = itemName.getText().toString();

                if (nameTXT.equals("")) {

                    Toast.makeText(MainScreen.this, "Specify item name", Toast.LENGTH_SHORT).show();

                } else {

                    Boolean checkDeleteData = DB.deleteData(nameTXT);

                    if (checkDeleteData == true) {

                        Toast.makeText(MainScreen.this, "Item deleted", Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(MainScreen.this, "Item delete failed", Toast.LENGTH_SHORT).show();

                    }

                }
            }
        });

        viewBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){

                Cursor res = DB.getData();

                if(res.getCount() == 0) {

                    Toast.makeText(MainScreen.this, "Inventory is empty", Toast.LENGTH_SHORT).show();
                    return;

                }

                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()) {

                    buffer.append("Name: " + res.getString(0) + "\n");
                    buffer.append("Quantity: " + res.getString(1) + "\n\n");

                }

                AlertDialog.Builder builder = new AlertDialog.Builder(MainScreen.this);
                builder.setCancelable(true);
                builder.setTitle("Inventory");
                builder.setMessage(buffer.toString());
                builder.show();



        }

        });

    }
}