package com.zybooks.inventoryapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBInventory extends SQLiteOpenHelper {

    public static final String DBNAME = "InventoryDB.db";

    public DBInventory(Context context) {

        super(context, "InventoryDB.db", null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase SQLdb) {

        SQLdb.execSQL("create Table inventory(itemName TEXT primary key, itemQuantity TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase SQLdb, int i, int i1) {

        SQLdb.execSQL("drop Table if exists inventory");

    }

    public Boolean addData(String itemname, String quantity) {

        SQLiteDatabase SQLdb = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("itemName", itemname);
        contentValues.put("itemQuantity", quantity);

        long result = SQLdb.insert("inventory", null, contentValues);

        if (result == -1) {

            return false;

        } else {

            return true;

        }
    }

    public Boolean updateData(String itemname, String quantity) {

        SQLiteDatabase SQLdb = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("itemQuantity", quantity);
        Cursor cursor = SQLdb.rawQuery("Select * from inventory where itemname = ?", new String[]{itemname});

        if (cursor.getCount() > 0) {


            long result = SQLdb.update("inventory", contentValues, "itemName=?", new String[]{itemname});

            if (result == -1) {

                return false;

            } else {

                return true;

            }
        }
        else{

            return false;

        }
    }

    public Boolean deleteData(String itemname) {

        SQLiteDatabase SQLdb = this.getWritableDatabase();

        Cursor cursor = SQLdb.rawQuery("Select * from inventory where itemname = ?", new String[]{itemname});

        if (cursor.getCount() > 0) {


            long result = SQLdb.delete("inventory", "itemName=?", new String[]{itemname});

            if (result == -1) {

                return false;

            } else {

                return true;

            }
        }
        else{

            return false;

        }
    }

    public Cursor getData() {

        SQLiteDatabase SQLdb = this.getWritableDatabase();

        Cursor cursor = SQLdb.rawQuery("Select * from inventory", null);

        return cursor;

    }

}